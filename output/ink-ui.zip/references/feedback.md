# Ink-Ui - Feedback

**Pages:** 3

---

## Navigation Menu

**URL:** https://github.com/vadimdemedes/ink-ui/blob/main/docs/badge.md

**Contents:**
  - Uh oh!
  - Uh oh!

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

---

## Navigation Menu

**URL:** https://github.com/vadimdemedes/ink-ui/blob/main/docs/spinner.md

**Contents:**
  - Uh oh!
  - Uh oh!

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

---

## Navigation Menu

**URL:** https://github.com/vadimdemedes/ink-ui/blob/main/docs/alert.md

**Contents:**
  - Uh oh!
  - Uh oh!

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

There was an error while loading. Please reload this page.

---
