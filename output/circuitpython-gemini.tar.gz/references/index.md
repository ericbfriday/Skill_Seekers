# Circuitpython Documentation Index

## Categories

### Core Modules
**File:** `core_modules.md`
**Pages:** 143

### Getting Started
**File:** `getting_started.md`
**Pages:** 2

### Libraries
**File:** `libraries.md`
**Pages:** 18

### Network
**File:** `network.md`
**Pages:** 4
